import json
from pathlib import Path
from .protocol import atomic_json


class Store:
    def __init__(self, folder, volume):
        self.path = Path(folder) / "state.json"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data = {"version": 1, "volume": volume, "last_media": None,
                     "media": {}, "commands": {}}
        errors = []
        for path in (self.path, Path(str(self.path) + ".bak")):
            if not path.exists():
                continue
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                if (not isinstance(data, dict) or data.get("version") != 1
                        or type(data.get("volume")) is not int or not 0 <= data["volume"] <= 100
                        or not isinstance(data.get("media"), dict)
                        or not isinstance(data.get("commands"), dict)):
                    raise ValueError("Invalid state journal")
                self.data = data
                return
            except (OSError, ValueError) as error:
                errors.append(str(error))
        if errors:
            raise RuntimeError("State and backup unreadable; preserved for inspection")

    def save(self):
        atomic_json(self.path, self.data)
